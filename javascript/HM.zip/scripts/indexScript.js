$(document).ready(function() {
   // checkconnection();          
    // Fast-click
   // alert($.parseJSON(localStorage.getItem("appVersionVal")));
    // $('#idVersion').text($.parseJSON(localStorage.getItem("appVersionVal")));  
    $("#imgProg").hide();
    document.addEventListener("deviceready", onDeviceReady, false); 
    function onDeviceReady() {
        // Fast-click to elliminate the delay of 300ms
        FastClick.attach(document.body); }   
            //$("#idOk").click(function () {
            //    $('.closeMe').trigger('click');
            //});
            //$(window).load(function() {
            //    setTimeout(function() {
            //        $('#preloader').fadeOut('slow', function() {
            //        });
            //    }, 2000);
            //});
            $('#txtBillNo').keyup(function () {
                var yourInput = $(this).val();
                re = /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi;
                var isSplChar = re.test(yourInput);
                if (isSplChar) {
                    var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
                    $(this).val(no_spl_char);
                }
            });   
            var MobNo = '';
            $('#btnLogin').click(function () {
                //checkconnection();
                $("#imgProg").show();
                MobNo = $("#txtBillNo").val();
                var msg = '';
                if (MobNo == '') {
                    msg = msg == '' ? "- Please enter Mobile No" : msg + "\n- Please enter Mobile No";
                }
                if (MobNo != '') {
                    if (isNaN(MobNo)) {
                        msg = msg == '' ? "- Mobile No can not alphanumeric" : msg + "\n- Mobile No can not alphanumeric";
                    }
                }                
                if ($("#txtPassword").val() == '') {
                    msg = msg == '' ? "\n\n- Please enter Password" : msg + '\n\n- Please enter Password';
                }
                //if ($("#txtBillNo").val() == '' ) {
                //    msg = msg == '' ? "- Please fill Mobile No/Bill No" : msg + "\n- Please fill Mobile No/Bill No";
                //}
                //if ($("#txtPassword").val() == '') {
                //    msg = msg == '' ? "\n\n- Please fill Password" : msg + '\n\n- Please fill Password';
                //}                          
                if (msg != '') {
                    $("#imgProg").hide();
                    alert(msg);
                   return false;
                }
                else {
                    ValidateUser();
                }

            });         

        });
        function ValidateUser() {
            var MobileNo = $("#txtBillNo").val();
            var BillNO = $("#txtBillNo").val();
            var Password = $("#txtPassword").val();
            var LoginBy='';
            var Age = '';
            var DisclaimerAccept = '';
            var Email = '';
            var ErrorMessage = '';
            var HISRegistrationId = '';
            var HospitalID = '';
            var ImageType = '';
            var ImagePath = '';
            var LoginType = '';           
            var PatientName = '';
            var Patientimage = '';
            var TermsCondition = '';
            var UserType='';
            var url = '';
            var EncounterId = '';
            var FacilityId = '';
            //If Bill No starts with Alpha Numeric Charector Its a Bill NO set O for Mobile No
            //If Bill No starts with Numeric Its a Mobile NO set O for Bill No
            ////if (!isNaN(BillNO)) {
            ////    BillNO = 0;
            ////    LoginBy='M';
            ////}
            ////else {
            ////    MobileNo =0;
            ////     LoginBy='B';
            ////    //alert('alpha numbric');                
            ////}
           // var domainName = '';
           // $.getJSON("webservicepath.json").done(function (data) {$.each(data, function (index, val) { if (val.key = "webServiceUrl") { domainName = val.value; } });});
            var param = '/' + MobileNo + '/' + Password;
            // alert(param);
            //if (localStorage.length != 0) {
               // alert($.parseJSON(localStorage.getItem("domainName")));     }
            var xhr = $.ajax({
                type: "GET",
                async: false,
                 url: $.parseJSON(localStorage.getItem("domainName")) + "Service1.svc/MobPatientLogin" + param,
                //url: "http://180.179.206.91:86/Service1.svc/MobPatientLogin" + param,
              //  url: "http://akhil10:478/Service1.svc/MobPatientLogin" + param,
                success: function(data) {
                    // alert('Fetched succesfully !'); 
                    if (data.length < 1) {
                        $("#imgProg").hide();
                        alert('Fail : Mobile No and Password combination is not correct..');
                        return;
                    }
                    $.each(data, function(index, value) {
                        Age = value.Age;
                        //  DisclaimerAccept = value.DisclaimerAccept;                                             
                        Email = value.Email;
                     //   ErrorMessage = value.ErrorMessage;
                        HISRegistrationId = value.HISRegistrationId;
                        HospitalID = value.HospitalID;
                        EncounterId = value.EncounterId;
                        FacilityId = value.FacilityId;
                       // alert('HISRegistrationId=' + HISRegistrationId);
                        ImagePath = value.ImagePath;
                        localStorage.setItem("ImagePath", JSON.stringify(ImagePath));                        
                      //  LoginType = value.LoginType;                        
                        if(value.MobileNo!=null ||value.MobileNo.length!=0 )
		               {
			             MobileNo = value.MobileNo;
		               }
                        PatientName = value.PatientName;
                        UserType = value.UserType;
                       // Patientimage = value.Patientimage;
                      //  TermsCondition = value.TermsCondition;
                    });
                    //If error code is not blank then show Error Message to User 
                    if (ErrorMessage != '') {
                        $("#imgProg").hide();
                        alert(ErrorMessage);
                        return false;
                    }
                    else {
                        if (UserType=='P')
                        {                          
                            url = "Menu.html?PatientName=" + encodeURIComponent(PatientName) + "&Email=" + encodeURIComponent(Email) + "&MobileNo=" + encodeURIComponent(MobileNo) + "&HISRegistrationId=" + encodeURIComponent(HISRegistrationId) + "&HospitalID=" + encodeURIComponent(HospitalID) + "&Age=" + encodeURIComponent(Age);
                          // url = "Menu.html?PatientName=" + encodeURIComponent(PatientName) + "&Email=" + encodeURIComponent(Email) + "&MobileNo=" + encodeURIComponent(MobileNo);
                        }
                        else
                        {
                            url = "DoctorMenu.html?PatientName=" + encodeURIComponent(PatientName) + "&Email=" + encodeURIComponent(Email) + "&MobileNo=" + encodeURIComponent(MobileNo) + "&HISRegistrationId=" + encodeURIComponent(HISRegistrationId) + "&HospitalID=" + encodeURIComponent(HospitalID) + "&Age=" + encodeURIComponent(Age) + "&EncId=" + encodeURIComponent(EncounterId)+"&FacId="+encodeURIComponent(FacilityId);
                        }
                        // alert(url);
                        window.location = url;
                    }
                },
                error: function (result) {
                    $("#imgProg").hide();
                    alert('Internet connection not found or error while data fetching');
                }                
            });
        }
        $("#idSignUp").click(function () {            
            var path = "SignUpN2.html";
            localStorage.setItem('pageName', JSON.stringify('index'));           
            window.location.href = path;
            return false;
        });
        function checkconnection() {            
            var status = navigator.onLine;           
            if (!status) {               
                alert("No Internet found on your Mobile Phone.");
                return false;
            }
        }
        //$(window).load(function () {
        //    alert($('#idVersion').val());
        //});
