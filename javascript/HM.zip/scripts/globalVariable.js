﻿/// <reference path="../js/Js1.8.3Min.js" />

///var domainNameVal = 'http://172.16.10.50:6025/';
///var domainNameVal = 'http://43.242.214.195:86/';
var domainNameVal = 'http://raj:886/';
var appVersionVal = '1.0.0';
localStorage.setItem("domainName", JSON.stringify(domainNameVal));
localStorage.setItem("appVersion", JSON.stringify(appVersionVal));
